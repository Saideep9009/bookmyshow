import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { Movies } from './movies';

const routes: Routes = [{ path: '', component: Movies }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MoviesRoutingModule {}

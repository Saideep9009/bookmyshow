import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MoviesRoutingModule } from './movies-routing-module';
import { Movies } from './movies';

@NgModule({
  declarations: [Movies],
  imports: [CommonModule, MoviesRoutingModule]
})
export class MoviesModule {}

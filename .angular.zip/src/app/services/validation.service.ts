import { Injectable } from '@angular/core';
import {
  AbstractControl,
  FormGroup,
  ValidationErrors,
  ValidatorFn
} from '@angular/forms';
import { VALIDATION_MESSAGES } from './validation-messages';

@Injectable({
  providedIn: 'root'
})
export class ValidationService {
  getErrorMessage(controlName: string, form: FormGroup): string {
    const control = form.get(controlName);

    if (!control || !control.errors || !(control.touched || control.dirty)) {
      return '';
    }

    const controlMessages = VALIDATION_MESSAGES[controlName];
    if (!controlMessages) {
      return '';
    }

    const firstErrorKey = Object.keys(control.errors)[0];
    const errorValue = control.errors[firstErrorKey];
    const messageConfig = controlMessages[firstErrorKey];

    if (!messageConfig) {
      return '';
    }

    return typeof messageConfig === 'function'
      ? messageConfig(errorValue)
      : messageConfig;
  }

  noLeadingSpaceValidator(): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      const value = control.value;

      if (value == null || value === '') {
        return null;
      }

      return typeof value === 'string' && value.trimStart() !== value
        ? { leadingSpace: true }
        : null;
    };
  }

  noSpaceValidator(): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      const value = control.value;

      if (value == null || value === '') {
        return null;
      }

      return /\s/.test(value) ? { spaceNotAllowed: true } : null;
    };
  }

  noWhitespaceOnlyValidator(): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      const value = control.value;

      if (value == null || value === '') {
        return null;
      }

      return typeof value === 'string' && value.trim().length === 0
        ? { whitespaceOnly: true }
        : null;
    };
  }
}
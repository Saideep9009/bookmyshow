export const VALIDATION_MESSAGES: {
  [controlName: string]: {
    [errorKey: string]: string | ((error: any) => string);
  };
} = {
  name: {
    required: 'Name is required',
    minlength: (error: any) => `Name must be at least ${error.requiredLength} characters`,
    maxlength: (error: any) => `Name cannot exceed ${error.requiredLength} characters`,
    leadingSpace: 'Name should not start with whitespace',
    whitespaceOnly: 'Name cannot contain only spaces',
    pattern: 'Name should contain only letters and single spaces between words'
  },

  username: {
    required: 'Username is required',
    minlength: (error: any) => `Username must be at least ${error.requiredLength} characters`,
    maxlength: (error: any) => `Username cannot exceed ${error.requiredLength} characters`,
    leadingSpace: 'Username should not start with whitespace',
    whitespaceOnly: 'Username cannot contain only spaces',
    spaceNotAllowed: 'Username should not contain spaces',
    pattern: 'Username can contain only letters, numbers and underscore'
  },

  password: {
    required: 'Password is required',
    minlength: (error: any) => `Password must be at least ${error.requiredLength} characters`,
    maxlength: (error: any) => `Password cannot exceed ${error.requiredLength} characters`,
    leadingSpace: 'Password should not start with whitespace',
    whitespaceOnly: 'Password cannot contain only spaces',
    pattern: 'Password must contain at least one letter and one number'
  },

  email: {
    required: 'Email is required',
    email: 'Enter a valid email address',
    leadingSpace: 'Email should not start with whitespace',
    whitespaceOnly: 'Email cannot contain only spaces'
  },

  phoneNumber: {
    required: 'Phone number is required',
    pattern: 'Phone number must be exactly 10 digits'
  }
};
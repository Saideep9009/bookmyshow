import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, AbstractControl } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-reset-password',
  standalone: false,
  templateUrl: './reset-password.html',
  styleUrl: './reset-password.scss',
})
export class ResetPassword implements OnInit {
resetPasswordForm!: FormGroup;

  token: string = '';
  loading = false;
  successMessage = '';
  errorMessage = '';

  // change this if your backend base url is different
  private resetPasswordApi = 'https://localhost:6767/api/login/reset-password';

  constructor(
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private http: HttpClient
  ) {}

  ngOnInit(): void {
    this.resetPasswordForm = this.fb.group(
      {
        newPassword: ['', [Validators.required, Validators.minLength(4)]],
        confirmPassword: ['', [Validators.required]]
      },
      {
        validators: this.passwordMatchValidator
      }
    );

    this.route.queryParamMap.subscribe(params => {
      this.token = params.get('token') || '';

      if (!this.token) {
        this.errorMessage = 'Invalid or missing reset token.';
      }
    });
  }

  passwordMatchValidator(form: AbstractControl): { [key: string]: boolean } | null {
    const password = form.get('newPassword')?.value;
    const confirmPassword = form.get('confirmPassword')?.value;

    if (!password || !confirmPassword) {
      return null;
    }

    return password === confirmPassword ? null : { passwordMismatch: true };
  }

  validateControl(controlName: string): string {
    const control = this.resetPasswordForm.get(controlName);

    if (!control || !control.touched || !control.errors) {
      return '';
    }

    if (control.errors['required']) {
      if (controlName === 'newPassword') {
        return 'New password is required';
      }
      if (controlName === 'confirmPassword') {
        return 'Confirm password is required';
      }
    }

    if (control.errors['minlength']) {
      return 'Password must be at least 4 characters';
    }

    return '';
  }

  get passwordMismatchError(): string {
    if (
      this.resetPasswordForm.hasError('passwordMismatch') &&
      this.resetPasswordForm.get('confirmPassword')?.touched
    ) {
      return 'Passwords do not match';
    }

    return '';
  }

  onSubmit(): void {
    this.successMessage = '';
    this.errorMessage = '';

    if (!this.token) {
      this.errorMessage = 'Invalid or missing reset token.';
      return;
    }

    if (this.resetPasswordForm.invalid) {
      this.resetPasswordForm.markAllAsTouched();
      return;
    }

    const payload = {
      token: this.token,
      newPassword: this.resetPasswordForm.value.newPassword
    };

    this.loading = true;

    this.http.post<any>(this.resetPasswordApi, payload).subscribe({
      next: (res) => {
        this.loading = false;

        if (res?.status) {
          this.successMessage = 'Password reset successfully. Redirecting to login...';
          this.resetPasswordForm.reset();

          setTimeout(() => {
            this.router.navigate(['/login']);
          }, 1800);
        } else {
          this.errorMessage = res?.error?.description || 'Unable to reset password.';
        }
      },
      error: (err: { error: { error: { description: any; }; message: any; }; }) => {
        this.loading = false;
        this.errorMessage =
          err?.error?.error?.description ||
          err?.error?.message ||
          'Something went wrong while resetting the password.';
      }
    });
  }

  goToLogin(): void {
    this.router.navigate(['/login']);
  }
}

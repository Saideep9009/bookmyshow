import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { ValidationService } from '../../services/validation.service';

@Component({
  selector: 'app-login',
  standalone: false,
  templateUrl: './login.html',
  styleUrls: ['./login.scss'],
})
export class Login implements OnInit {
  loginForm!: FormGroup;
  signupForm!: FormGroup;

  loading = false;
  signupLoading = false;
  forgotPasswordLoading = false;

  errorMessage = '';
  signupErrorMessage = '';
  signupSuccessMessage = '';
  forgotPasswordErrorMessage = '';
  forgotPasswordSuccessMessage = '';

  isSignupMode = false;
  showForgotPassword = false;

  constructor(
    private fb: FormBuilder,
    private http: HttpClient,
    private router: Router,
    private authService: AuthService,
    public validationService: ValidationService
  ) {}

  ngOnInit(): void {
    this.initializeForms();
  }

  initializeForms(): void {
    this.loginForm = this.fb.group({
      username: [
        '',
        [
          Validators.required,
          Validators.minLength(4),
          Validators.maxLength(20),
          this.validationService.noLeadingSpaceValidator(),
          this.validationService.noWhitespaceOnlyValidator(),
          this.validationService.noSpaceValidator(),
          Validators.pattern(/^[A-Za-z0-9_]+$/)
        ]
      ],
      password: [
        '',
        [
          Validators.required,
          Validators.minLength(3),
          Validators.maxLength(20),
          this.validationService.noLeadingSpaceValidator(),
          this.validationService.noWhitespaceOnlyValidator()
        ]
      ]
    });

    this.signupForm = this.fb.group({
      name: [
        '',
        [
          Validators.required,
          Validators.minLength(3),
          Validators.maxLength(50),
          this.validationService.noLeadingSpaceValidator(),
          this.validationService.noWhitespaceOnlyValidator(),
          Validators.pattern(/^[A-Za-z]+(?: [A-Za-z]+)*$/)
        ]
      ],
      username: [
        '',
        [
          Validators.required,
          Validators.minLength(4),
          Validators.maxLength(20),
          this.validationService.noLeadingSpaceValidator(),
          this.validationService.noWhitespaceOnlyValidator(),
          this.validationService.noSpaceValidator(),
          Validators.pattern(/^[A-Za-z0-9_]+$/)
        ]
      ],
      password: [
        '',
        [
          Validators.required,
          Validators.minLength(6),
          Validators.maxLength(20),
          this.validationService.noLeadingSpaceValidator(),
          this.validationService.noWhitespaceOnlyValidator(),
          Validators.pattern(/^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d@$!%*?&]+$/)
        ]
      ],
      email: [
        '',
        [
          Validators.required,
          Validators.email,
          this.validationService.noLeadingSpaceValidator(),
          this.validationService.noWhitespaceOnlyValidator()
        ]
      ],
      phoneNumber: [
        '',
        [
          Validators.required,
          Validators.pattern(/^[0-9]{10}$/)
        ]
      ]
    });
  }

  validateControl(controlName: string, form: FormGroup): string {
    return this.validationService.getErrorMessage(controlName, form);
  }

  toggleSignup(): void {
    this.isSignupMode = !this.isSignupMode;

    this.errorMessage = '';
    this.signupErrorMessage = '';
    this.signupSuccessMessage = '';
    this.forgotPasswordErrorMessage = '';
    this.forgotPasswordSuccessMessage = '';
    this.showForgotPassword = false;

    this.loginForm.reset();
    this.signupForm.reset();
  }

  toggleForgotPassword(): void {
    this.showForgotPassword = !this.showForgotPassword;
    this.forgotPasswordErrorMessage = '';
    this.forgotPasswordSuccessMessage = '';
  }

  onLogin(): void {
    this.errorMessage = '';

    if (this.loginForm.invalid) {
      this.loginForm.markAllAsTouched();
      return;
    }

    this.loading = true;

    const payload = {
      username: this.loginForm.value.username.trim(),
      password: this.loginForm.value.password
    };

    this.http.post<any>('https://localhost:6767/api/Login/login', payload).subscribe({
      next: (res) => {
        this.loading = false;

        if (res?.status && res?.data?.token) {
          this.authService.setToken(res.data.token);
          this.router.navigate(['/master']);
        } else {
          this.errorMessage = res?.message || 'Invalid username or password';
        }
      },
      error: (err) => {
        this.loading = false;
        this.errorMessage = err?.error?.message || 'Something went wrong';
      }
    });
  }

  onForgotPassword(): void {
    this.forgotPasswordErrorMessage = '';
    this.forgotPasswordSuccessMessage = '';

    const usernameControl = this.loginForm.get('username');

    if (!usernameControl) {
      this.forgotPasswordErrorMessage = 'Username field is not available.';
      return;
    }

    usernameControl.markAsTouched();

    if (usernameControl.invalid) {
      this.forgotPasswordErrorMessage = 'Please enter a valid username first.';
      return;
    }

    const username = (usernameControl.value || '').trim();

    if (!username) {
      this.forgotPasswordErrorMessage = 'Username is required.';
      return;
    }

    this.forgotPasswordLoading = true;

    const headers = new HttpHeaders({
      'Content-Type': 'application/json'
    });

    this.http.post<any>(
      'https://localhost:6767/api/Login/forgot-password',
      JSON.stringify(username),
      { headers }
    ).subscribe({
      next: (res) => {
        this.forgotPasswordLoading = false;

        if (res?.status) {
          this.forgotPasswordSuccessMessage =
            res?.data?.message || 'Reset email request queued successfully.';
        } else {
          this.forgotPasswordErrorMessage =
            res?.error?.description || 'Unable to process forgot password request.';
        }
      },
      error: (err) => {
        this.forgotPasswordLoading = false;
        this.forgotPasswordErrorMessage =
          err?.error?.error?.description ||
          err?.error?.message ||
          'Something went wrong while queueing the reset email.';
      }
    });
  }

  onSignup(): void {
    this.signupErrorMessage = '';
    this.signupSuccessMessage = '';

    if (this.signupForm.invalid) {
      this.signupForm.markAllAsTouched();
      this.signupErrorMessage = 'Please correct the highlighted fields';
      return;
    }

    this.signupLoading = true;

    const payload = {
      name: this.signupForm.value.name.trim(),
      username: this.signupForm.value.username.trim(),
      password: this.signupForm.value.password,
      email: this.signupForm.value.email.trim(),
      phoneNumber: this.signupForm.value.phoneNumber
    };

    this.http.post<any>('https://localhost:6767/api/Login/register', payload)
      .subscribe({
        next: (res) => {
          this.signupLoading = false;
          if (res?.status) {
            this.signupSuccessMessage = 'Signup successful. Please login.';
            this.signupForm.reset();

            setTimeout(() => {
              this.isSignupMode = false;
              this.signupSuccessMessage = '';
            }, 1200);
          } else {
            this.signupErrorMessage = res?.message || 'Signup failed';
          }
        },
        error: (err) => {
          this.signupLoading = false;
          this.signupErrorMessage = err?.error?.message || 'Something went wrong';
        }
      });
  }
}
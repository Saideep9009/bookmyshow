import { Component } from '@angular/core';

@Component({
  selector: 'app-manage-theatres',
  standalone: false,
  templateUrl: './manage-theatres.html',
  styleUrl: './manage-theatres.scss',
})
export class ManageTheatres {

}

import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { ManageTheatresRoutingModule } from './manage-theatres-routing-module';
import { ManageTheatres } from './manage-theatres';
import { TheatreLayoutBuilder } from './theatre-layout-builder/theatre-layout-builder';

@NgModule({
  declarations: [ManageTheatres, TheatreLayoutBuilder],
  imports: [CommonModule, FormsModule, ManageTheatresRoutingModule]
})
export class ManageTheatresModule {
  
 }

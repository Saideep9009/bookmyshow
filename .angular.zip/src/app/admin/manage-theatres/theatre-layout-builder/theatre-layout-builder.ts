import { Component } from '@angular/core';

@Component({
  selector: 'app-theatre-layout-builder',
  standalone: false,
  templateUrl: './theatre-layout-builder.html',
  styleUrl: './theatre-layout-builder.scss',
})
export class TheatreLayoutBuilder {

}

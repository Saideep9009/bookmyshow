import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TheatreLayoutBuilder } from './theatre-layout-builder';

describe('TheatreLayoutBuilder', () => {
  let component: TheatreLayoutBuilder;
  let fixture: ComponentFixture<TheatreLayoutBuilder>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [TheatreLayoutBuilder]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TheatreLayoutBuilder);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

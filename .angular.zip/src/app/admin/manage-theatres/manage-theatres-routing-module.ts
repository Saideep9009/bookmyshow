import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ManageTheatres } from './manage-theatres';
import { TheatreLayoutBuilder } from './theatre-layout-builder/theatre-layout-builder';

const routes: Routes = [
  { path: '', component: ManageTheatres },
   { 
    path: 'layout-builder', 
    component: TheatreLayoutBuilder 
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ManageTheatresRoutingModule { }

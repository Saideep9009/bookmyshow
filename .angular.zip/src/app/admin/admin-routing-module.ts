import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: 'dashboard',
    loadChildren: () => import('./dashboard/dashboard-module').then(m => m.DashboardModule)
  },
  {
    path: 'manage-movies',
    loadChildren: () => import('./manage-movies/manage-movies-module').then(m => m.ManageMoviesModule)
  },
  {
    path: 'manage-theatres',
    loadChildren: () => import('./manage-theatres/manage-theatres-module').then(m => m.ManageTheatresModule)
  },
  { path: '', redirectTo: 'dashboard', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminRoutingModule { }

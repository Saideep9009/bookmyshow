import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ManageMovies } from './manage-movies';

const routes: Routes = [
  { path: '', component: ManageMovies }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ManageMoviesRoutingModule { }

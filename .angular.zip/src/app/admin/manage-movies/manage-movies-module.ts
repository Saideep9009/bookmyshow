import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ManageMoviesRoutingModule } from './manage-movies-routing-module';
import { ManageMovies } from './manage-movies';

@NgModule({
  declarations: [ManageMovies],
  imports: [CommonModule, ManageMoviesRoutingModule]
})
export class ManageMoviesModule { }

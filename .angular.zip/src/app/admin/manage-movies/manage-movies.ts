import { Component } from '@angular/core';

@Component({
  selector: 'app-manage-movies',
  standalone: false,
  templateUrl: './manage-movies.html',
  styleUrl: './manage-movies.scss',
})
export class ManageMovies {

}

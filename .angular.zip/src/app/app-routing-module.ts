import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { Login } from './login/login/login';
import { AuthGuard } from './services/auth.gaurd';

const routes: Routes = [
 {
    path: 'login',
    loadChildren: () => import('./login/login-module').then(m => m.LoginModule)
  },
  
 {
    path: 'master',
    canActivate: [AuthGuard],
    loadChildren: () => import('./master/master-module').then(m => m.MasterModule)
  },
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: '**', redirectTo: 'login' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoreModels.DTO
{
  public class EmailEnqueueRequestDto
  {
    public string SourceApp { get; set; } = "";
    public string? CorrelationId { get; set; }

    public string TemplateKey { get; set; } = "";
    public int? TemplateVersion { get; set; }

    public List<string> To { get; set; } = new();
    public List<string> Cc { get; set; } = new();
    public List<string> Bcc { get; set; } = new();

    public Dictionary<string, string> Variables { get; set; } = new();

  }
  public class EmailEnqueueResponseDto
  {
    public long EmailMessageId { get; set; }
    public string Status { get; set; } = "";
  }
}

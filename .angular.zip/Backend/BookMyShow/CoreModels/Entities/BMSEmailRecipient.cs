using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoreModels.Entities
{
  [Table("BMS_EmailRecipient", Schema = "dbo")]
  public class BMSEmailRecipient
  {
    [Key]
    public long EmailRecipientId { get; set; }

    public long EmailMessageId { get; set; }

    [Required, MaxLength(10)]
    public string RecipientType { get; set; } = "";

    [Required, MaxLength(320)]
    public string EmailAddress { get; set; } = "";
  }
}

using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoreModels.Entities
{
  [Table("BMS_EmailTemplate", Schema = "dbo")]
  public class BMSEmailTemplate
  {
    [Key]
    public int TemplateId { get; set; }

    [Required, MaxLength(100)]
    public string TemplateKey { get; set; } = "";

    public int Version { get; set; }

    [Required, MaxLength(500)]
    public string SubjectTemplate { get; set; } = "";

    [Required]
    public string BodyHtmlTemplate { get; set; } = "";

    public bool IsActive { get; set; }

    public DateTime CreatedAtUtc { get; set; }
  }

}

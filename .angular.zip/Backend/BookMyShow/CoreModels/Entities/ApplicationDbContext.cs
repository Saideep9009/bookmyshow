using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoreModels.Entities
{
  public class ApplicationDbContext : DbContext
  {
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

    public DbSet<BMSEmailTemplate> EmailTemplates => Set<BMSEmailTemplate>();
    public DbSet<BMSEmailMessage> EmailMessages => Set<BMSEmailMessage>();
    public DbSet<BMSEmailRecipient> EmailRecipients => Set<BMSEmailRecipient>();

    public DbSet<UserEntity> BmsUsers { get; set; }

    public DbSet<BMSPasswordResetRequest> BMSPasswordResetRequests { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
      modelBuilder.Entity<BMSEmailTemplate>()
          .HasIndex(x => new { x.TemplateKey, x.Version })
          .IsUnique();

      modelBuilder.Entity<BMSEmailMessage>()
          .HasIndex(x => new { x.Status, x.NextRetryAtUtc, x.CreatedAtUtc });

      modelBuilder.Entity<BMSEmailRecipient>()
          .HasIndex(x => x.EmailMessageId);

      modelBuilder.Entity<BMSEmailRecipient>()
          .HasIndex(x => x.EmailAddress);
    }

  }
}

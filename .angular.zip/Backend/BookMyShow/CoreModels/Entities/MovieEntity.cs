using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoreModels.Entities
{
  public class MovieEntity
  {
    public int Id { get; set; }

    public string Title { get; set; }

    public string Language { get; set; }

    public string Genre { get; set; }
  }
}

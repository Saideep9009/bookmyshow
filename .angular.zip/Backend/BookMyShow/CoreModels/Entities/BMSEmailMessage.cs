using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoreModels.Entities
{
  [Table("BMS_EmailMessage", Schema = "dbo")]
  public class BMSEmailMessage
  {
    [Key]
    public long EmailMessageId { get; set; }

    [Required, MaxLength(100)]
    public string SourceApp { get; set; } = "";

    [MaxLength(100)]
    public string? CorrelationId { get; set; }

    [Required, MaxLength(100)]
    public string TemplateKey { get; set; } = "";

    public int? TemplateVersion { get; set; }

    public string? VariablesJson { get; set; }

    [Required, MaxLength(20)]
    public string Status { get; set; } = "PENDING";

    public int AttemptCount { get; set; }

    public DateTime NextRetryAtUtc { get; set; }

    [MaxLength(2000)]
    public string? LastError { get; set; }

    public DateTime CreatedAtUtc { get; set; }

    public DateTime? SentAtUtc { get; set; }

    [MaxLength(200)]
    public string? LeaseOwner { get; set; }

    public DateTime? LeaseUntilUtc { get; set; }
  }
}

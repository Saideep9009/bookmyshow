using ApplicationLayer.Interface;
using CoreModels.DTO;
using CoreModels.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer
{
    public class LoginService
    {
    private readonly IUnitOfWork _unitOfWork;

    public LoginService(IUnitOfWork unitOfWork)
    {
      _unitOfWork = unitOfWork;
    }

    public async Task<UserDTO?> GetUser(string username, string password)
    {
      return await _unitOfWork.LoginRepository.GetUser(username, password);
    }
    public async Task<List<MovieDTO>> GetAllMovies()
    {
      return await _unitOfWork.LoginRepository.GetAllMovies();
    }
    public async Task<long> InsertForgotPasswordEmailRequest(string username)
    {
      return await _unitOfWork.LoginRepository.InsertForgotPasswordEmailRequest(username);
    }
    public async Task<bool> ResetPassword(string token, string newPassword)
    {
      return await _unitOfWork.LoginRepository.ResetPassword(token, newPassword);
    }
  }
}

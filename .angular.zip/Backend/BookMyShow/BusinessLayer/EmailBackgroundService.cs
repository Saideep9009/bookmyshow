using CoreModels.DTO;
using CoreModels.Entities;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System.Data;
using System.Net;
using System.Net.Mail;
using System.Text.Json;

namespace BusinessLayer
{
  public class EmailBackgroundService : BackgroundService
  {
    private readonly IServiceScopeFactory _scopeFactory;
    private readonly ILogger<EmailBackgroundService> _logger;
    private readonly SmtpSettings _smtpSettings;

    // Unique ID for this running service instance
    private readonly string _workerId = $"{Environment.MachineName}-{Guid.NewGuid():N}";

    private const string StatusPending = "PENDING";
    private const string StatusSending = "SENDING";
    private const string StatusSent = "SENT";
    private const string StatusFailed = "FAILED";

    private const string RecipientTo = "TO";
    private const string RecipientCc = "CC";
    private const string RecipientBcc = "BCC";

    // Tune these based on your server and SMTP/provider capacity
    private const int BatchSize = 50;              // claim 50 emails each cycle
    private const int WorkerCount = 5;             // 5 parallel workers
    private const int MaxAttempts = 3;

    private static readonly TimeSpan PollInterval = TimeSpan.FromSeconds(5);
    private static readonly TimeSpan LeaseDuration = TimeSpan.FromMinutes(2);

    public EmailBackgroundService(
        IServiceScopeFactory scopeFactory,
        ILogger<EmailBackgroundService> logger,
        IOptions<SmtpSettings> smtpOptions)
    {
      _scopeFactory = scopeFactory;
      _logger = logger;
      _smtpSettings = smtpOptions.Value;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
      _logger.LogInformation("Email background service started. WorkerId: {WorkerId}", _workerId);

      while (!stoppingToken.IsCancellationRequested)
      {
        try
        {
          await ProcessPendingEmails(stoppingToken);
        }
        catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested)
        {
          break;
        }
        catch (Exception ex)
        {
          _logger.LogError(ex, "Unexpected error while processing pending emails.");
        }

        try
        {
          await Task.Delay(PollInterval, stoppingToken);
        }
        catch (OperationCanceledException)
        {
          break;
        }
      }

      _logger.LogInformation("Email background service stopped. WorkerId: {WorkerId}", _workerId);
    }

    private async Task ProcessPendingEmails(CancellationToken stoppingToken)
    {
      List<long> claimedIds;

      // Claim emails safely in one scope/context
      using (var scope = _scopeFactory.CreateScope())
      {
        var context = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();

        claimedIds = await ClaimPendingEmailIdsAsync(
            context,
            BatchSize,
            _workerId,
            LeaseDuration,
            stoppingToken);
      }

      if (claimedIds.Count == 0)
        return;

      var queue = new Queue<long>(claimedIds);
      var queueLock = new object();

      var workerTasks = Enumerable.Range(1, WorkerCount).Select(async workerNo =>
      {
        while (!stoppingToken.IsCancellationRequested)
        {
          long emailMessageId;

          lock (queueLock)
          {
            if (queue.Count == 0)
              return;

            emailMessageId = queue.Dequeue();
          }

          try
          {
            await ProcessSingleEmail(emailMessageId, workerNo, stoppingToken);
          }
          catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested)
          {
            return;
          }
          catch (Exception ex)
          {
            _logger.LogError(ex,
                "Worker {WorkerNo} failed unexpectedly while processing email {EmailMessageId}",
                workerNo, emailMessageId);
          }
        }
      });

      await Task.WhenAll(workerTasks);
    }

    private async Task ProcessSingleEmail(long emailMessageId, int workerNo, CancellationToken stoppingToken)
    {
      using var scope = _scopeFactory.CreateScope();
      var context = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();

      var email = await context.Set<BMSEmailMessage>()
          .FirstOrDefaultAsync(x =>
              x.EmailMessageId == emailMessageId &&
              x.Status == StatusSending &&
              x.LeaseOwner == _workerId,
              stoppingToken);

      if (email == null)
        return;

      try
      {
        var recipients = await context.Set<BMSEmailRecipient>()
            .AsNoTracking()
            .Where(x => x.EmailMessageId == email.EmailMessageId)
            .ToListAsync(stoppingToken);

        if (recipients.Count == 0)
          throw new InvalidOperationException("No recipients found for this email.");

        var template = await GetTemplate(context, email, stoppingToken);

        if (template == null)
          throw new InvalidOperationException("Email template not found.");

        if (string.IsNullOrWhiteSpace(template.SubjectTemplate))
          throw new InvalidOperationException("Email subject template is empty.");

        if (string.IsNullOrWhiteSpace(template.BodyHtmlTemplate))
          throw new InvalidOperationException("Email body template is empty.");

        var variables = DeserializeVariables(email.VariablesJson);

        var subject = ReplacePlaceholders(template.SubjectTemplate, variables);
        var body = ReplacePlaceholders(template.BodyHtmlTemplate, variables);

        // renew lease just before sending
        await RenewLeaseAsync(context, email.EmailMessageId, stoppingToken);

        await SendEmail(subject, body, recipients, stoppingToken);

        var dbEmail = await context.Set<BMSEmailMessage>()
            .FirstOrDefaultAsync(x =>
                x.EmailMessageId == email.EmailMessageId &&
                x.Status == StatusSending &&
                x.LeaseOwner == _workerId,
                stoppingToken);

        if (dbEmail == null)
          return;

        dbEmail.Status = StatusSent;
        dbEmail.SentAtUtc = DateTime.UtcNow;
        dbEmail.LastError = null;
        dbEmail.LeaseOwner = null;
        dbEmail.LeaseUntilUtc = null;

        await context.SaveChangesAsync(stoppingToken);

        _logger.LogInformation(
            "Worker {WorkerNo} successfully sent email {EmailMessageId}",
            workerNo, email.EmailMessageId);
      }
      catch (Exception ex)
      {
        _logger.LogError(ex,
            "Worker {WorkerNo} failed to process email {EmailMessageId}",
            workerNo, email.EmailMessageId);

        var dbEmail = await context.Set<BMSEmailMessage>()
            .FirstOrDefaultAsync(x =>
                x.EmailMessageId == email.EmailMessageId &&
                x.Status == StatusSending &&
                x.LeaseOwner == _workerId,
                stoppingToken);

        if (dbEmail == null)
          return;

        dbEmail.AttemptCount += 1;
        dbEmail.LastError = Truncate(ex.ToString(), 2000);
        dbEmail.LeaseOwner = null;
        dbEmail.LeaseUntilUtc = null;

        if (dbEmail.AttemptCount >= MaxAttempts)
        {
          dbEmail.Status = StatusFailed;
        }
        else
        {
          dbEmail.Status = StatusPending;
          dbEmail.NextRetryAtUtc = DateTime.UtcNow.AddMinutes(GetRetryDelayMinutes(dbEmail.AttemptCount));
        }

        await context.SaveChangesAsync(stoppingToken);
      }
    }

    private async Task<List<long>> ClaimPendingEmailIdsAsync(
        ApplicationDbContext context,
        int batchSize,
        string workerId,
        TimeSpan leaseDuration,
        CancellationToken stoppingToken)
    {
      var nowUtc = DateTime.UtcNow;
      var leaseUntilUtc = nowUtc.Add(leaseDuration);

      const string sql = @"
;WITH cte AS
(
    SELECT TOP (@batchSize) em.*
    FROM [dbo].[BMS_EmailMessage] em WITH (UPDLOCK, READPAST, ROWLOCK)
    WHERE
        (
            em.[Status] = @pendingStatus
            AND em.[NextRetryAtUtc] <= @nowUtc
        )
        OR
        (
            em.[Status] = @sendingStatus
            AND em.[LeaseUntilUtc] IS NOT NULL
            AND em.[LeaseUntilUtc] <= @nowUtc
        )
    ORDER BY em.[CreatedAtUtc]
)
UPDATE cte
SET
    [Status] = @sendingStatus,
    [LeaseOwner] = @workerId,
    [LeaseUntilUtc] = @leaseUntilUtc
OUTPUT INSERTED.[EmailMessageId];";

      var ids = new List<long>();
      var conn = context.Database.GetDbConnection();
      var shouldClose = false;

      if (conn.State != ConnectionState.Open)
      {
        await conn.OpenAsync(stoppingToken);
        shouldClose = true;
      }

      IDbContextTransaction? transaction = null;

      try
      {
        if (context.Database.CurrentTransaction == null)
        {
          transaction = await context.Database.BeginTransactionAsync(stoppingToken);
        }

        using var cmd = conn.CreateCommand();
        cmd.CommandText = sql;
        cmd.CommandType = CommandType.Text;
        cmd.Transaction = context.Database.CurrentTransaction?.GetDbTransaction();

        cmd.Parameters.Add(new SqlParameter("@batchSize", batchSize));
        cmd.Parameters.Add(new SqlParameter("@pendingStatus", StatusPending));
        cmd.Parameters.Add(new SqlParameter("@sendingStatus", StatusSending));
        cmd.Parameters.Add(new SqlParameter("@workerId", workerId));
        cmd.Parameters.Add(new SqlParameter("@nowUtc", nowUtc));
        cmd.Parameters.Add(new SqlParameter("@leaseUntilUtc", leaseUntilUtc));

        using var reader = await cmd.ExecuteReaderAsync(stoppingToken);
        while (await reader.ReadAsync(stoppingToken))
        {
          ids.Add(reader.GetInt64(0));
        }

        if (transaction != null)
        {
          await transaction.CommitAsync(stoppingToken);
        }
      }
      finally
      {
        if (transaction != null)
        {
          await transaction.DisposeAsync();
        }

        if (shouldClose)
        {
          await conn.CloseAsync();
        }
      }

      return ids;
    }

    private async Task RenewLeaseAsync(
        ApplicationDbContext context,
        long emailMessageId,
        CancellationToken stoppingToken)
    {
      var email = await context.Set<BMSEmailMessage>()
          .FirstOrDefaultAsync(x =>
              x.EmailMessageId == emailMessageId &&
              x.Status == StatusSending &&
              x.LeaseOwner == _workerId,
              stoppingToken);

      if (email == null)
        return;

      email.LeaseUntilUtc = DateTime.UtcNow.Add(LeaseDuration);
      await context.SaveChangesAsync(stoppingToken);
    }

    private async Task<BMSEmailTemplate?> GetTemplate(
        ApplicationDbContext context,
        BMSEmailMessage email,
        CancellationToken stoppingToken)
    {
      if (email.TemplateVersion.HasValue)
      {
        return await context.Set<BMSEmailTemplate>()
            .AsNoTracking()
            .FirstOrDefaultAsync(x =>
                x.TemplateKey == email.TemplateKey &&
                x.Version == email.TemplateVersion.Value,
                stoppingToken);
      }

      return await context.Set<BMSEmailTemplate>()
          .AsNoTracking()
          .Where(x => x.TemplateKey == email.TemplateKey && x.IsActive)
          .OrderByDescending(x => x.Version)
          .FirstOrDefaultAsync(stoppingToken);
    }

    private Dictionary<string, string> DeserializeVariables(string? variablesJson)
    {
      if (string.IsNullOrWhiteSpace(variablesJson))
        return new Dictionary<string, string>();

      return JsonSerializer.Deserialize<Dictionary<string, string>>(variablesJson)
             ?? new Dictionary<string, string>();
    }

    private string ReplacePlaceholders(string template, Dictionary<string, string> variables)
    {
      var result = template;

      foreach (var item in variables)
      {
        result = result.Replace(
            "{{" + item.Key + "}}",
            item.Value ?? string.Empty,
            StringComparison.OrdinalIgnoreCase);
      }

      return result;
    }

    private async Task SendEmail(
        string subject,
        string body,
        List<BMSEmailRecipient> recipients,
        CancellationToken stoppingToken)
    {
      using var message = new MailMessage
      {
        From = new MailAddress(_smtpSettings.FromEmail, _smtpSettings.FromName),
        Subject = subject,
        Body = body,
        IsBodyHtml = true
      };

      foreach (var recipient in recipients)
      {
        if (string.IsNullOrWhiteSpace(recipient.EmailAddress))
          continue;

        var type = recipient.RecipientType?.Trim().ToUpperInvariant();
        var address = recipient.EmailAddress.Trim();

        try
        {
          switch (type)
          {
            case RecipientTo:
              message.To.Add(address);
              break;
            case RecipientCc:
              message.CC.Add(address);
              break;
            case RecipientBcc:
              message.Bcc.Add(address);
              break;
          }
        }
        catch
        {
          // skip invalid email address
        }
      }

      if (message.To.Count == 0 && message.CC.Count == 0 && message.Bcc.Count == 0)
        throw new InvalidOperationException("No valid recipients found.");

      using var client = new SmtpClient(_smtpSettings.Host, _smtpSettings.Port)
      {
        Credentials = new NetworkCredential(_smtpSettings.UserName, _smtpSettings.Password),
        EnableSsl = _smtpSettings.EnableSsl
      };

      stoppingToken.ThrowIfCancellationRequested();
      await client.SendMailAsync(message);
    }

    private static int GetRetryDelayMinutes(int attemptCount)
    {
      return attemptCount switch
      {
        1 => 1,
        2 => 2,
        _ => 4
      };
    }

    private static string Truncate(string value, int maxLength)
    {
      if (string.IsNullOrEmpty(value))
        return value;

      return value.Length <= maxLength ? value : value.Substring(0, maxLength);
    }
  }


}

using CoreModels.DTO;
using CoreModels.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApplicationLayer.Interface
{
  public interface ILoginRepository
  {
    Task<UserDTO> GetUser(string username, string password);

    Task<List<MovieDTO>> GetAllMovies();

    Task<long> InsertForgotPasswordEmailRequest(string username);

    Task<bool> ResetPassword(string token, string newPassword);


  }
}

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApplicationLayer.Interface
{
  public interface IUnitOfWork : IDisposable
  {
    ILoginRepository LoginRepository { get; }




    void Commit();
  }
}

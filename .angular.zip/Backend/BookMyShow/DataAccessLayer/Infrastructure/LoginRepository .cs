using ApplicationLayer.Interface;
using CoreModels.DTO;
using CoreModels.Entities;
using Microsoft.EntityFrameworkCore;
using System.Text.Json;

namespace DataAccessLayer.Infrastructure
{
  public class LoginRepository : ILoginRepository
  {
    private readonly ApplicationDbContext _context;

    public LoginRepository(ApplicationDbContext context)
    {
      _context = context;
    }

    public async Task<UserDTO?> GetUser(string username, string password)
    {
      var user = await _context.Set<UserEntity>()
          .FirstOrDefaultAsync(x =>
              x.UserName == username &&
              x.PasswordHash == password &&   // using plain for now
              x.IsActive &&
              !x.IsDeleted);

      if (user == null)
        return null;

      return new UserDTO
      {
        Id = user.UserId,
        Username = user.UserName,
        Email = user.Email,
        Role = user.Role,
        Password = user.PasswordHash   // for now (not recommended later)
      };
    }


    public Task<List<MovieDTO>> GetAllMovies()
    {
      var movies = new List<MovieEntity>
        {
            new MovieEntity { Id = 1, Title = "Avengers", Language = "English", Genre = "Action" },
            new MovieEntity { Id = 2, Title = "RRR", Language = "Telugu", Genre = "Action" },
            new MovieEntity { Id = 3, Title = "Inception", Language = "English", Genre = "Sci-Fi" }
        };

      var result = movies.Select(x => new MovieDTO
      {
        Title = x.Title,
        Language = x.Language,
        Genre = x.Genre
      }).ToList();

      return Task.FromResult(result);
    }


    public async Task<long> InsertForgotPasswordEmailRequest(string username)
    {
      if (string.IsNullOrWhiteSpace(username))
        throw new Exception("Username is required.");

      username = username.Trim();

      var user = await _context.Set<UserEntity>()
          .FirstOrDefaultAsync(x =>
              x.UserName == username &&
              x.IsActive &&
              !x.IsDeleted);

      if (user == null)
        throw new Exception("User not found.");

      if (string.IsNullOrWhiteSpace(user.Email))
        throw new Exception("Email is not configured for this user.");

      var template = await _context.Set<BMSEmailTemplate>()
          .FirstOrDefaultAsync(x => x.TemplateKey == "FORGOT_PASSWORD" && x.IsActive);

      if (template == null)
        throw new Exception("Forgot password template not found.");

      var resetToken = Guid.NewGuid().ToString();
      var correlationId = Guid.NewGuid().ToString();
      var expiryMinutes = 15;
      var expiresAtUtc = DateTime.UtcNow.AddMinutes(expiryMinutes);

      var resetLink = $"https://localhost:4200/login/reset-password?token={resetToken}";

      var variables = new Dictionary<string, string>
      {
        ["AppName"] = "BookMyShow",
        ["UserName"] = string.IsNullOrWhiteSpace(user.Name) ? user.UserName : user.Name,
        ["ResetLink"] = resetLink,
        ["ExpiryMinutes"] = expiryMinutes.ToString(),
        ["CorrelationId"] = correlationId,
        ["TimeUtc"] = DateTime.UtcNow.ToString("O")
      };

      using var transaction = await _context.Database.BeginTransactionAsync();

      try
      {
        var passwordResetRequest = new BMSPasswordResetRequest
        {
          UserId = user.UserId,
          UserName = user.UserName,
          Email = user.Email.Trim(),
          ResetToken = resetToken,
          ExpiresAtUtc = expiresAtUtc,
          IsUsed = false,
          CreatedAtUtc = DateTime.UtcNow,
          UsedAtUtc = null
        };

        _context.Set<BMSPasswordResetRequest>().Add(passwordResetRequest);
        await _context.SaveChangesAsync();

        var emailMessage = new BMSEmailMessage
        {
          SourceApp = "BookMyShow",
          CorrelationId = correlationId,
          TemplateKey = template.TemplateKey,
          TemplateVersion = template.Version,
          VariablesJson = JsonSerializer.Serialize(variables),
          Status = "PENDING",
          AttemptCount = 0,
          NextRetryAtUtc = DateTime.UtcNow,
          LastError = null,
          CreatedAtUtc = DateTime.UtcNow,
          SentAtUtc = null
        };

        _context.Set<BMSEmailMessage>().Add(emailMessage);
        await _context.SaveChangesAsync();

        var recipient = new BMSEmailRecipient
        {
          EmailMessageId = emailMessage.EmailMessageId,
          RecipientType = "TO",
          EmailAddress = user.Email.Trim()
        };

        _context.Set<BMSEmailRecipient>().Add(recipient);
        await _context.SaveChangesAsync();

        await transaction.CommitAsync();

        return emailMessage.EmailMessageId;
      }
      catch
      {
        await transaction.RollbackAsync();
        throw;
      }
    }



    public async Task<bool> ResetPassword(string token, string newPassword)
    {
      if (string.IsNullOrWhiteSpace(token) || string.IsNullOrWhiteSpace(newPassword))
        return false;

      var resetRequest = await _context.Set<BMSPasswordResetRequest>()
          .FirstOrDefaultAsync(x =>
              x.ResetToken == token &&
              !x.IsUsed &&
              x.ExpiresAtUtc >= DateTime.UtcNow);

      if (resetRequest == null)
        return false;

      var user = await _context.Set<UserEntity>()
          .FirstOrDefaultAsync(x =>
              x.UserId == resetRequest.UserId &&
              x.IsActive &&
              !x.IsDeleted);

      if (user == null)
        return false;

      using var transaction = await _context.Database.BeginTransactionAsync();

      try
      {
        // Update password (plain for now as per your requirement)
        user.PasswordHash = newPassword;
        user.UpdatedAtUtc = DateTime.UtcNow;

        // Mark token as used
        resetRequest.IsUsed = true;
        resetRequest.UsedAtUtc = DateTime.UtcNow;

        await _context.SaveChangesAsync();

        await transaction.CommitAsync();

        return true;
      }
      catch
      {
        await transaction.RollbackAsync();
        throw;
      }
    }

  }
}

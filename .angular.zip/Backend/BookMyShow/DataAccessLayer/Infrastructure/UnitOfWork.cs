using ApplicationLayer.Interface;
using CoreModels.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer.Infrastructure
{
    public  class UnitOfWork : IUnitOfWork
    {
    private readonly ApplicationDbContext _dbcontext;

    public ILoginRepository LoginRepository { get; }


    public UnitOfWork(ApplicationDbContext dBContext)
    {

    _dbcontext = dBContext;
    LoginRepository = new LoginRepository(_dbcontext);

    }
    public void Commit()
    {
      _dbcontext.SaveChanges();
    }

    public void Dispose()
    {
      GC.SuppressFinalize(this);
    }

  }
}

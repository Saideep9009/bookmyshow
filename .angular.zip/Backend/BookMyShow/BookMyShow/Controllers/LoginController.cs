using ApplicationLayer.Interface;
using BusinessLayer;
using CoreModels.DTO;
using CoreModels.Entities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Text;
using System.Text.Json;


namespace BookMyShow.Controllers
{
  [Route("api/[controller]")]
  [ApiController]
  public class LoginController : ControllerBase
  {
    private readonly LoginService _service;
    private readonly ILogger<LoginController> _logger;
    private readonly IConfiguration _configuration;

    public LoginController(
        IUnitOfWork unitOfWork,
        ILogger<LoginController> logger,
        IConfiguration configuration)
    {
      _service = new LoginService(unitOfWork);
      _logger = logger;
      _configuration = configuration;
    }

    [HttpPost("login")]
    public async Task<GenericResponse> Login([FromBody] UserDTO request)
    {
      var response = new GenericResponse();

      try
      {
        var user = await _service.GetUser(request.Username, request.Password);

        if (user == null)
        {
          response.Status = false;
          response.Error = new Error
          {
            Code = "401",
            Description = "Invalid username or password"
          };

          return response;
        }

        var token = GenerateJwtToken(user);

        response.Status = true;
        response.Data = new
        {
          User = user,
          Token = token
        };

        return response;
      }
      catch (Exception ex)
      {
        _logger.LogError(ex, "Login failed");

        response.Status = false;
        response.Error = new Error
        {
          Code = "500",
          Description = ex.Message
        };

        return response;
      }
    }

    [Authorize(Roles = "Admin")]
    [HttpGet("GetAllMovies")]
    public async Task<GenericResponse> GetAllMovies()
    {
      var response = new GenericResponse();

      try
      {
        var movies = await _service.GetAllMovies();

        response.Status = true;
        response.Data = movies;

        return response;
      }
      catch (Exception ex)
      {
        _logger.LogError(ex, "Error fetching movies");

        response.Status = false;
        response.Error = new Error
        {
          Code = "500",
          Description = "Internal server error"
        };

        return response;
      }
    }


    [HttpPost("forgot-password")]
    public async Task<GenericResponse> ForgotPassword([FromBody] string username)
    {
      var response = new GenericResponse();

      try
      {
        var emailMessageId = await _service.InsertForgotPasswordEmailRequest(username);

        response.Status = true;
        response.Data = new
        {
          EmailMessageId = emailMessageId,
          Message = "Forgot password email request queued successfully."
        };

        return response;
      }
      catch (Exception ex)
      {
        _logger.LogError(ex, "Error queueing forgot password email request");

        response.Status = false;
        response.Error = new Error
        {
          Code = "500",
          Description = "Internal server error"
        };

        return response;
      }
    }




[HttpPost("reset-password")]
  public async Task<GenericResponse> ResetPassword([FromBody] JsonElement body)
  {
    var response = new GenericResponse();

    try
    {
      var token = body.GetProperty("token").GetString();
      var newPassword = body.GetProperty("newPassword").GetString();

      if (string.IsNullOrWhiteSpace(token) || string.IsNullOrWhiteSpace(newPassword))
      {
        response.Status = false;
        response.Error = new Error
        {
          Code = "400",
          Description = "Token and new password are required"
        };
        return response;
      }

      var result = await _service.ResetPassword(token!, newPassword!);

      if (!result)
      {
        response.Status = false;
        response.Error = new Error
        {
          Code = "400",
          Description = "Invalid or expired token"
        };
        return response;
      }

      response.Status = true;
      response.Data = new
      {
        Message = "Password reset successfully"
      };

      return response;
    }
    catch (Exception ex)
    {
      _logger.LogError(ex, "Error resetting password");

      response.Status = false;
      response.Error = new Error
      {
        Code = "500",
        Description = "Internal server error"
      };

      return response;
    }
  }

  private string GenerateJwtToken(UserDTO user)
    {
      var claims = new List<System.Security.Claims.Claim>
    {
        new System.Security.Claims.Claim(
            System.Security.Claims.ClaimTypes.NameIdentifier,
            user.Id.ToString()),

        new System.Security.Claims.Claim(
            System.Security.Claims.ClaimTypes.Name,
            user.Username ?? string.Empty),

        new System.Security.Claims.Claim(
            System.Security.Claims.ClaimTypes.Email,
            user.Email ?? string.Empty),

        new System.Security.Claims.Claim(
            System.Security.Claims.ClaimTypes.Role,
            user.Role ?? "User")
    };

      var key = new SymmetricSecurityKey(
          Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]!));

      var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

      var token = new JwtSecurityToken(
          issuer: _configuration["Jwt:Issuer"],
          audience: _configuration["Jwt:Audience"],
          claims: claims,
          expires: DateTime.UtcNow.AddHours(2),
          signingCredentials: creds
      );

      return new JwtSecurityTokenHandler().WriteToken(token);
    }
  }
}
